/**
 * 创建 DOM
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
(function () {
    const PAGE_WIDTH = 578;
    const ORIGIN_PAGE_WIDTH = 820;
    const PREVIEW_PAGE_WIDTH = 390;
    const IMAGE_WRAPPER_CLASS = "FEISHU_2_WIXIN_image-wrapper";
    // 处理剪切板数据
    const handleClipboard = () => __awaiter(this, void 0, void 0, function* () {
        // 获取剪切板数据
        const text = yield navigator.clipboard.read();
        if (!text.length)
            return null;
        try {
            const blob = yield text[0].getType("text/html");
            if (blob) {
                const html = yield blob.text();
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, "text/html");
                return doc;
            }
        }
        catch (error) {
            console.error("error", error);
        }
        return null;
    });
    // 复制到剪贴板
    const copyToClipboard = (html) => __awaiter(this, void 0, void 0, function* () {
        const serializer = new XMLSerializer();
        // 重新计算图片的宽度
        html.querySelectorAll(`.${IMAGE_WRAPPER_CLASS}`).forEach((img) => {
            const width = img.dataset.width;
            if (!width)
                return;
            const percent = Number(width) / ORIGIN_PAGE_WIDTH;
            img.style.width = `${percent * PAGE_WIDTH}px`;
        });
        try {
            const htmlStrList = Array.from(html.children).map((item) => {
                return serializer.serializeToString(item);
            });
            const data = new Blob(htmlStrList, {
                type: "text/html",
            });
            const clipboardItemData = new ClipboardItem({ "text/html": data });
            yield navigator.clipboard.write([clipboardItemData]);
        }
        catch (error) {
            console.error("复制到剪贴板失败", error);
        }
    });
    // 获取当前页面的图片和白板
    const getImages = () => __awaiter(this, void 0, void 0, function* () {
        var _a;
        // 滚动容器
        const scrollContainer = document.querySelector(".bear-web-x-container");
        // 滚动到最上面
        scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.scrollTo(0, 0);
        const result = {};
        let count = 0;
        while (count < 10) {
            yield new Promise((resolve) => {
                setTimeout(() => {
                    resolve(null);
                }, 400);
            });
            // 获取当前页面的 whiteboard 和 img 元素，并转换为 base64
            const whiteboards = Array.from(document.querySelectorAll(".docx-whiteboard-block"));
            for (let i = 0; i < whiteboards.length; i++) {
                const canvas = whiteboards[i].querySelector("canvas");
                const dataUrl = canvas === null || canvas === void 0 ? void 0 : canvas.toDataURL("image/png");
                const recordId = whiteboards[i].getAttribute("data-record-id");
                result[recordId] = {
                    src: dataUrl,
                    properties: {
                        width: canvas === null || canvas === void 0 ? void 0 : canvas.width,
                        height: canvas === null || canvas === void 0 ? void 0 : canvas.height,
                    },
                };
            }
            const imgs = Array.from(document.querySelectorAll(".docx-image-block"));
            for (let i = 0; i < imgs.length; i++) {
                const img = imgs[i].querySelector("img");
                const canvas = document.createElement("canvas");
                const ctx = canvas.getContext("2d");
                // 确保 canvas 的尺寸与图片相同
                canvas.width = img.naturalWidth;
                canvas.height = img.naturalHeight;
                // 将图片绘制到 canvas 上
                ctx.drawImage(img, 0, 0);
                // 转换为 data URL
                const dataUrl = canvas.toDataURL("image/png");
                const recordId = imgs[i].getAttribute("data-record-id");
                const recordToken = (_a = imgs[i]
                    .querySelector("[image-token]")) === null || _a === void 0 ? void 0 : _a.getAttribute("image-token");
                result[recordId] = {
                    src: dataUrl,
                    properties: {
                        width: img.width,
                        height: img.height,
                    },
                };
                if (recordToken) {
                    result[recordToken] = {
                        src: dataUrl,
                        properties: {
                            width: img.width,
                            height: img.height,
                        },
                    };
                }
            }
            // 高亮块的 emoji
            const callouts = Array.from(document.querySelectorAll(".docx-callout-block"));
            for (let i = 0; i < callouts.length; i++) {
                const emoji = callouts[i].querySelector(".emoji-mart-emoji > span");
                const recordId = callouts[i].getAttribute("data-record-id");
                result[recordId] = {
                    src: emoji.textContent,
                };
            }
            // 判断当前容器是不是已经滚到底
            const isBottom = Math.abs((scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.scrollHeight) -
                (scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.scrollTop) -
                (scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.clientHeight)) < 10;
            if (!isBottom) {
                // 滚动一屏
                scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.scrollBy(0, scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.clientHeight);
            }
            else {
                break;
            }
        }
        return result;
    });
    const getRecordData = (doc) => {
        const recordElement = doc.querySelector("span[data-lark-record-data]");
        if (!recordElement)
            return null;
        const recordData = recordElement.getAttribute("data-lark-record-data");
        return JSON.parse(recordData);
    };
    const PAGE_MAP = {
        init: undefined,
        result: undefined,
    };
    const tranverseRecord2Tree = (recordMap, id) => {
        const result = [];
        const record = recordMap[id];
        if (!record)
            return result;
        const children = record.snapshot.children;
        for (let i = 0; i < (children === null || children === void 0 ? void 0 : children.length); i++) {
            const child = children[i];
            if (!recordMap[child])
                continue;
            result.push({
                id: child,
                snapshot: recordMap[child].snapshot,
                children: tranverseRecord2Tree(recordMap, child),
            });
        }
        return result;
    };
    // 全局数据存储
    const globalStore = {
        recordData: null,
        imgMap: null,
        doc: null,
    };
    const BLOCK_RENDERER = {
        heading: (recordData) => {
            var _a, _b;
            const LEVEL_FONT_SIZE = [28, 25, 22, 20, 18, 16];
            const level = +((_a = recordData.type.match(/heading(\d)/)) === null || _a === void 0 ? void 0 : _a[1]);
            const section = document.createElement(`h${level}`);
            section.setAttribute("style", `
          color: rgba(0, 0, 0, 0.9);
          font-weight: 700;
          line-height: 1.5;
          margin-top: 15px;
          margin-bottom: 15px;
          box-sizing: border-box;
          font-size: ${(_b = LEVEL_FONT_SIZE[level - 1]) !== null && _b !== void 0 ? _b : LEVEL_FONT_SIZE[5]}px;
          text-align: ${recordData.align};
      `);
            // 处理文案
            section.innerHTML = BLOCK_RENDERER.text({
                align: "left",
                text: recordData.text,
            }).innerHTML;
            return section;
        },
        text: (textSnapshot, options) => {
            var _a, _b, _c;
            const attrMap = {
                textHighlightBackground: (value) => {
                    return {
                        style: [
                            {
                                key: "background-color",
                                value,
                                priority: "high",
                            },
                        ],
                    };
                },
                textHighlight: (value) => {
                    return {
                        style: [
                            {
                                key: "color",
                                value,
                            },
                        ],
                    };
                },
                inlineCode: () => {
                    return {
                        style: [
                            {
                                key: "background-color",
                                value: "rgb(245, 246,247)",
                                priority: "low",
                            },
                            {
                                key: "border-radius",
                                value: "4px",
                            },
                            {
                                key: "line-height",
                                value: "1.5",
                            },
                            {
                                key: "box-sizing",
                                value: "border-box",
                            },
                            {
                                key: "border",
                                value: "1px solid rgb(222, 224, 227)",
                            },
                            {
                                key: "margin",
                                value: "0 3px",
                            },
                            {
                                key: "padding",
                                value: "1px 2px",
                            },
                        ],
                    };
                },
                bold: () => {
                    return {
                        style: [
                            {
                                key: "font-weight",
                                value: "700",
                            },
                        ],
                    };
                },
                link: () => {
                    // 暂不处理
                    return {
                        style: [],
                    };
                },
                strikethrough: () => {
                    return {
                        style: [
                            {
                                key: "text-decoration",
                                value: "line-through",
                                merge: true,
                            },
                        ],
                    };
                },
                italic: () => {
                    return {
                        style: [
                            {
                                key: "font-style",
                                value: "italic",
                            },
                        ],
                    };
                },
                underline: () => {
                    return {
                        style: [
                            {
                                key: "text-decoration",
                                value: "underline",
                                merge: true,
                            },
                        ],
                    };
                },
            };
            const textInfo = textSnapshot.text;
            const numberToAttrib = textInfo.apool.numToAttrib;
            const initialAttributedTexts = textInfo.initialAttributedTexts;
            // 处理文案
            let text = (_a = initialAttributedTexts.text) === null || _a === void 0 ? void 0 : _a[0];
            const p = document.createElement("section");
            p.setAttribute("style", `
        color: rgba(0, 0, 0, 0.9);
        font-size: 15px;
        line-height: 1.5;
        text-align: ${textSnapshot.align || "left"};
        box-sizing: border-box;
        ${(_b = options === null || options === void 0 ? void 0 : options.containerStyle) !== null && _b !== void 0 ? _b : ""}
      `);
            if (!text)
                return p;
            if ((_c = initialAttributedTexts === null || initialAttributedTexts === void 0 ? void 0 : initialAttributedTexts.attribs) === null || _c === void 0 ? void 0 : _c[0]) {
                // 值示例：'*0+6*0*1+4*0*2+4*0*3*2+4*0*4*5+h'
                // 数值只有 0-9,超过用字母表示
                const arrs = initialAttributedTexts.attribs[0].split("*0");
                let start = 0;
                while (arrs.length) {
                    const arr = arrs.shift();
                    if (!arr) {
                        continue;
                    }
                    const [fontStyleIndex, count] = arr.split("+");
                    const fontStyleIndexArr = fontStyleIndex.split("*");
                    const styleList = fontStyleIndexArr.reduce((arr, index) => {
                        var _a, _b;
                        const realIndex = Number.isNaN(Number(index)) && index
                            ? index.charCodeAt(0) - "a".charCodeAt(0) + 1 + 9
                            : Number(index);
                        if (!numberToAttrib[realIndex]) {
                            return arr;
                        }
                        const [key, value] = numberToAttrib[realIndex];
                        const styleList = ((_b = (_a = attrMap[key]) === null || _a === void 0 ? void 0 : _a.call(attrMap, value)) === null || _b === void 0 ? void 0 : _b.style) || [];
                        for (const style of styleList) {
                            const target = arr.find((item) => item.key === style.key);
                            if (target) {
                                if (style.merge) {
                                    target.value = `${target.value} ${style.value}`;
                                }
                                else if (style.priority === "high") {
                                    target.value = style.value;
                                }
                            }
                            else {
                                arr.push(style);
                            }
                        }
                        return arr;
                    }, []);
                    const countNum = Number.isNaN(Number(count))
                        ? count.charCodeAt(0) - "a".charCodeAt(0) + 1 + 9
                        : Number(count);
                    const end = start + countNum;
                    const span = document.createElement("span");
                    // 处理样式
                    span.textContent = text.slice(start, end);
                    const styleStr = styleList.reduce((str, style) => {
                        return `${str}${style.key}:${style.value};`;
                    }, "");
                    span.setAttribute("style", styleStr);
                    start = end;
                    p.appendChild(span);
                }
                // 处理剩余的文案
                if (start < text.length) {
                    const span = document.createElement("span");
                    span.textContent = text.slice(start);
                    p.appendChild(span);
                }
            }
            else {
                p.textContent = text;
            }
            return p;
        },
        list: (stack, info) => {
            // 递归处理
            let container;
            if (stack[0].snapshot.type === "ordered") {
                container = document.createElement("ol");
                container.setAttribute("type", ["1", "a", "i"][info.depth % 3]);
            }
            else {
                container = document.createElement("ul");
                container.setAttribute("type", ["disc", "circle", "square"][info.depth % 3]);
            }
            const list = stack;
            container.setAttribute("style", `
          font-size: 15px;
          padding-left: 20px;
        `);
            let start = "";
            while (list.length) {
                const node = list.shift();
                const { seq, text } = node.snapshot;
                const children = node.children;
                const li = document.createElement("li");
                li.appendChild(BLOCK_RENDERER.text({
                    align: "left",
                    text,
                }));
                if (!start) {
                    start = seq;
                }
                else if (seq !== "auto") {
                    li.setAttribute("value", seq);
                }
                if (children.length) {
                    const childTemp = createHTMLByTree({
                        tree: children,
                        depth: info.depth + 1,
                    });
                    li.appendChild(childTemp);
                }
                container.appendChild(li);
            }
            container.setAttribute("start", start);
            return container;
        },
        code: (codeInfo) => {
            const container = document.createElement("section");
            const pre = document.createElement("pre");
            const codeText = codeInfo.text.initialAttributedTexts.text[0];
            // 按照换行符分割
            const lines = codeText.split("\n");
            const temp = document.createDocumentFragment();
            lines.forEach((line) => {
                const code = document.createElement("code");
                code.textContent = line;
                code.setAttribute("style", `display: block;`);
                temp.appendChild(code);
            });
            pre.classList.add("code-snippet__js");
            pre.classList.add("code-snippet");
            pre.classList.add("code-snippet_nowrap");
            pre.setAttribute("style", "background-color: rgb(245, 246, 247); border-radius: 4px; font-size: 15px; line-height: 1.5; box-sizing: content-box; border: 1px solid rgb(222, 224, 227); margin: 20px 3px;");
            pre.appendChild(temp);
            container.appendChild(pre);
            return container;
        },
        quote: (quoteInfo, { depth, }) => {
            var _a;
            const container = document.createElement("section");
            const blockQuote = document.createElement("blockquote");
            blockQuote.setAttribute("style", `
        margin: 0;
        padding: 8px 8px;
        border-left: 4px solid #e0e0e0;
        background-color: #f9f9f9;
        font-size: 15px;
        line-height: 1.5;
        box-sizing: border-box;
      `);
            if ((_a = quoteInfo.children) === null || _a === void 0 ? void 0 : _a.length) {
                const temp = createHTMLByTree({
                    tree: quoteInfo.children,
                    depth: depth + 1,
                });
                // 给每个 p 标签加上 margin-top margin-bottom
                const aceLines = temp.querySelectorAll("& > p");
                aceLines.forEach((aceLine, index) => {
                    aceLine.setAttribute("style", `
            margin-top: ${index === 0 ? 0 : 10}px;
            margin-bottom: ${index === aceLines.length - 1 ? 0 : 10}px;
          `);
                });
                blockQuote.appendChild(temp);
            }
            container.appendChild(blockQuote);
            return container;
        },
        divider: (snapshot) => {
            const container = document.createElement("section");
            const divider = document.createElement("hr");
            divider.setAttribute("style", `
        border: none;
        border-top: 1px solid rgb(31,35,41,0.15);
      `);
            container.appendChild(divider);
            return container;
        },
        callout: (calloutInfo, { depth, }) => {
            var _a;
            const callout = document.createElement("section");
            const recordId = calloutInfo.id;
            const { background_color, border_color } = calloutInfo.snapshot;
            callout.setAttribute("style", `
        margin-top: 20px;
        margin-bottom: 20px;
        padding: 10px;
        letter-spacing: 0.578px;
        border-radius: 8px;
        line-height: 1.5;
        background-color: ${background_color};
        border: 1px solid ${border_color};
        color: rgb(119, 119, 119);
        font-size: 15px;
        display: flex;
      `);
            const emoji = document.createElement("span");
            emoji.textContent = globalStore.imgMap[recordId]["src"];
            emoji.setAttribute("style", `
        display: inline-block;
        vertical-align: top;
        margin-right: 10px;
        width: 20px;
    `);
            callout.appendChild(emoji);
            if ((_a = calloutInfo.children) === null || _a === void 0 ? void 0 : _a.length) {
                const temp = createHTMLByTree({
                    tree: calloutInfo.children,
                    parent: callout,
                    depth: depth + 1,
                });
                const tempContainer = document.createElement("section");
                tempContainer.appendChild(temp);
                tempContainer
                    .querySelectorAll("& > section")
                    .forEach((section, index) => {
                    if (index === 0) {
                        section.setAttribute("style", `
              ${section.getAttribute("style")};
              margin-top: 0; 
              margin-bottom: 10px; 
            `);
                    }
                    else if (index === temp.children.length - 1) {
                        section.setAttribute("style", `
              ${section.getAttribute("style")};
              margin-top: 10px; 
              margin-bottom: 0; 
            `);
                    }
                    else {
                        section.setAttribute("style", `
              ${section.getAttribute("style")};
              margin-top: 10px; 
              margin-bottom: 10px; 
            `);
                    }
                });
                tempContainer.setAttribute("style", `
          display: inline-block;
        `);
                callout.appendChild(tempContainer);
            }
            return callout;
        },
        table: (tableInfo, { depth, }) => {
            // 创建表格
            const table = document.createElement("table");
            table.setAttribute("style", `
        border-collapse: collapse;
      `);
            const tbody = document.createElement("tbody");
            const { cell_set, column_set, columns_id, rows_id, header_column, header_row, } = tableInfo.snapshot;
            const skipCell = [];
            // 构建表格
            rows_id.forEach((rowId, rowIndex) => {
                const tr = document.createElement("tr");
                // 是否首行为表头
                const isHeader = header_row && rowIndex === 0;
                columns_id.forEach((columnId, columnIndex) => {
                    if (skipCell.includes(`${rowId}${columnId}`))
                        return;
                    const cellElement = isHeader
                        ? document.createElement("th")
                        : document.createElement("td");
                    const cellInfo = cell_set[`${rowId}${columnId}`];
                    const cellWidth = column_set[columnId].column_width;
                    // 设置 rowspan 和 colspan
                    const merge_info = cellInfo.merge_info;
                    if (merge_info.row_span > 1) {
                        cellElement.setAttribute("rowspan", `${merge_info.row_span}`);
                        // 将合并的单元格加入 skipCell
                        for (let i = 1; i < merge_info.row_span; i++) {
                            const cellRowId = rows_id[rowIndex + i];
                            if (!cellRowId)
                                continue;
                            skipCell.push(`${cellRowId}${columnId}`);
                        }
                    }
                    if (merge_info.col_span > 1) {
                        cellElement.setAttribute("colspan", `${merge_info.col_span}`);
                        // 将合并的单元格加入 skipCell
                        for (let i = 1; i < merge_info.col_span; i++) {
                            const cellColumnId = columns_id[columnIndex + i];
                            if (!cellColumnId)
                                continue;
                            skipCell.push(`${rowId}${cellColumnId}`);
                        }
                    }
                    cellElement.setAttribute("data-id", `${rowId}${columnId}`);
                    // 设置宽度
                    cellElement.setAttribute("style", `
            border: 1px solid #ddd;
            width: ${cellWidth}px;
            padding: 4px;
          `);
                    if (isHeader) {
                        cellElement.setAttribute("style", `
              ${cellElement.getAttribute("style")};
              background-color: #f7f7f7;
              font-weight: 700;
              border-top: 2px solid #bbb;
            `);
                    }
                    // 设置列头样式
                    if (header_column && columnIndex === 0) {
                        cellElement.setAttribute("style", `
              ${cellElement.getAttribute("style")};
              background-color: #f7f7f7;
              font-weight: 700;
            `);
                    }
                    // 设置内容
                    // 获取内容块
                    const blockId = cellInfo.block_id;
                    if (blockId) {
                        const blockInfo = globalStore.recordData.recordMap[blockId];
                        if (blockInfo.snapshot.type !== "table_cell") {
                            // 如果不是表格单元格，则警告
                            console.warn("表格单元格内容不是 table_cell 类型", blockInfo);
                        }
                        else {
                            // 获取 children
                            const chilrenTree = tranverseRecord2Tree(globalStore.recordData.recordMap, blockId);
                            const block = createHTMLByTree({
                                tree: chilrenTree,
                                depth: depth + 1,
                            });
                            cellElement.appendChild(block);
                        }
                    }
                    tr.appendChild(cellElement);
                });
                tbody.appendChild(tr);
            });
            table.appendChild(tbody);
            return table;
        },
        whiteboard: (whiteboardInfo) => {
            const id = whiteboardInfo.id;
            const whiteboard = document.createElement("section");
            const imageInfo = globalStore.imgMap[id];
            if (!imageInfo) {
                console.debug("画板无法复制", whiteboardInfo);
                const span = document.createElement("span");
                span.textContent = "画板无法复制";
                span.setAttribute("style", `
          font-size: 20px;
          color: red;
        `);
                whiteboard.appendChild(span);
            }
            else {
                const img = document.createElement("img");
                img.src = imageInfo.src;
                const width = Math.max(PAGE_WIDTH, imageInfo.properties.width);
                img.setAttribute("style", `
          width: ${(imageInfo.properties.width / ORIGIN_PAGE_WIDTH) * 100}%;
          height: auto;
          border-radius: 8px;
        `);
                whiteboard.appendChild(img);
            }
            return whiteboard;
        },
        image: (imageInfo) => {
            var _a, _b, _c;
            const recordId = imageInfo.id;
            const { caption } = imageInfo.snapshot.image;
            const align = imageInfo.snapshot.align;
            const originWidth = globalStore.imgMap[recordId].properties.width;
            const imgContainer = document.createElement("section");
            const imgWrapper = document.createElement("span");
            imgContainer.setAttribute("style", `
        margin-top: 20px;
        margin-bottom: 20px;
        text-align: ${align};
      `);
            imgWrapper.setAttribute("style", `
        max-width: 100%;
        width: ${originWidth
                ? `${(originWidth / ORIGIN_PAGE_WIDTH) * PREVIEW_PAGE_WIDTH}px`
                : "100%"};
        display: inline-block;
      `);
            imgWrapper.classList.add(IMAGE_WRAPPER_CLASS);
            imgWrapper.setAttribute("data-width", `${originWidth}`);
            const img = document.createElement("img");
            const imgInfo = globalStore.imgMap[recordId];
            if (!imgInfo) {
                console.debug("图片复制失败", imageInfo);
                const p = document.createElement("section");
                p.textContent = "图片复制失败";
                p.setAttribute("style", `
          font-size: 20px;
          color: red;
          text-align: center;
        `);
                imgWrapper.appendChild(p);
            }
            else {
                img.src = imgInfo.src;
                img.setAttribute("style", `
          width: 100%;
          height: auto;
          border-radius: 8px;
        `);
                imgWrapper.appendChild(img);
                // 图片描述
                if (caption && ((_c = (_b = (_a = caption.text) === null || _a === void 0 ? void 0 : _a.initialAttributedTexts) === null || _b === void 0 ? void 0 : _b.text) === null || _c === void 0 ? void 0 : _c[0]) && !!caption.text.initialAttributedTexts.text[0].replace("\n", '').length) {
                    const captionElement = document.createDocumentFragment();
                    captionElement.appendChild(BLOCK_RENDERER.text({
                        align: "center",
                        text: caption.text,
                    }, {
                        containerStyle: `
              color: rgb(100, 106, 115);
              text-align: center;
              font-size: 14px;
              line-height: 22px;
            `,
                    }));
                    imgWrapper.appendChild(captionElement);
                }
            }
            imgContainer.appendChild(imgWrapper);
            return imgContainer;
        },
        grid: (gridInfo, { depth, }) => {
            const grid = document.createElement("section");
            grid.setAttribute("style", `
        display: flex;
        flex-wrap: nowrap;  
        gap: 10px;
      `);
            const children = gridInfo.children;
            children.forEach((child) => {
                const itemElement = document.createElement("section");
                itemElement.setAttribute("style", `
            flex: ${child.snapshot.width_ratio * 100};
        `);
                const childElement = createHTMLByTree({
                    tree: tranverseRecord2Tree(globalStore.recordData.recordMap, child.id),
                    depth: depth + 1,
                });
                itemElement.appendChild(childElement);
                grid.appendChild(itemElement);
            });
            return grid;
        },
    };
    const createHTMLByTree = ({ tree, depth, }) => {
        const root = parent
            ? document.createDocumentFragment()
            : document.createElement("div");
        while (tree.length) {
            const node = tree.shift();
            const type = node.snapshot.type;
            if (type.includes("heading")) {
                const block = BLOCK_RENDERER.heading(node.snapshot);
                block.style.marginTop = "20px";
                block.style.marginBottom = "20px";
                root.appendChild(block);
            }
            else if (type === "text") {
                const block = BLOCK_RENDERER.text(node.snapshot);
                block.style.marginTop = "20px";
                block.style.marginBottom = "20px";
                root.appendChild(block);
            }
            else if (type === "ordered") {
                // 继续往后找，直到不是 ol 为止
                let temp = node;
                const stack = [];
                while (temp && temp.snapshot.type === node.snapshot.type) {
                    stack.push(temp);
                    temp = tree.shift();
                }
                const block = BLOCK_RENDERER.list(stack, {
                    depth: depth !== null && depth !== void 0 ? depth : 0,
                });
                root.appendChild(block);
            }
            else if (type === "bullet") {
                // 继续往后找，直到不是 ul 为止
                let temp = node;
                const stack = [];
                while (temp && temp.snapshot.type === node.snapshot.type) {
                    stack.push(temp);
                    temp = tree.shift();
                }
                const block = BLOCK_RENDERER.list(stack, {
                    depth: depth !== null && depth !== void 0 ? depth : 0,
                });
                root.appendChild(block);
            }
            else if (type === "code") {
                const block = BLOCK_RENDERER.code(node.snapshot);
                block.style.marginTop = "20px";
                block.style.marginBottom = "20px";
                root.appendChild(block);
            }
            else if (type === "quote_container") {
                const block = BLOCK_RENDERER.quote(node, {
                    depth,
                });
                block.style.marginTop = "20px";
                block.style.marginBottom = "20px";
                root.appendChild(block);
            }
            else if (type === "divider") {
                const divider = BLOCK_RENDERER.divider(node.snapshot);
                divider.style.marginTop = "15px";
                divider.style.marginBottom = "15px";
                root.appendChild(divider);
            }
            else if (type === "callout") {
                const callout = BLOCK_RENDERER.callout(node, {
                    depth,
                });
                callout.style.marginTop = "20px";
                callout.style.marginBottom = "20px";
                root.appendChild(callout);
            }
            else if (type === "table") {
                const table = BLOCK_RENDERER.table(node, {
                    depth,
                });
                table.style.marginTop = "20px";
                table.style.marginBottom = "20px";
                root.appendChild(table);
            }
            else if (type === "whiteboard") {
                const whiteboard = BLOCK_RENDERER.whiteboard(node);
                whiteboard.style.marginTop = "20px";
                whiteboard.style.marginBottom = "20px";
                root.appendChild(whiteboard);
            }
            else if (type === "image") {
                const img = BLOCK_RENDERER.image(node);
                img.style.marginTop = "20px";
                img.style.marginBottom = "20px";
                root.appendChild(img);
            }
            else if (type === "grid") {
                const grid = BLOCK_RENDERER.grid(node, {
                    depth,
                });
                grid.style.marginTop = "20px";
                grid.style.marginBottom = "20px";
                root.appendChild(grid);
            }
        }
        return root;
    };
    const createHtml = (doc, imageMap) => {
        const wrapper = doc.querySelector("div[data-docx-has-block-data]");
        if (!wrapper)
            return null;
        const recordData = getRecordData(doc);
        globalStore.recordData = recordData;
        globalStore.imgMap = imageMap;
        globalStore.doc = doc;
        const tree = tranverseRecord2Tree(recordData.recordMap, recordData.rootId);
        const result = document.createElement("div");
        result.setAttribute("style", `
      word-wrap: break-word;
      line-height: 1.8;
      `);
        const resultHtml = createHTMLByTree({
            tree,
            depth: 0,
        });
        result.appendChild(resultHtml);
        return result;
    };
    const handleTransformClick = () => __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        // 获取剪切板数据
        const doc = yield handleClipboard();
        if (!doc || !doc.querySelector("span[data-lark-record-data]")) {
            // 判断当前如果是结果页，则回到初始页
            if (document.querySelector(".feishu-wx-container .show-result")) {
                // 移除 transform-btn 点击事件
                (_a = document
                    .querySelector(".feishu-wx-container .transform-btn")) === null || _a === void 0 ? void 0 : _a.removeEventListener("click", handleTransformClick);
                document.querySelector(".feishu-wx-container .content").innerHTML = "";
                document
                    .querySelector(".feishu-wx-container .content")
                    .appendChild(PAGE_MAP["init"].cloneNode(true));
                // 绑定 transform 点击事件
                document
                    .querySelector(".feishu-wx-container .transform")
                    .addEventListener("click", handleTransformClick);
            }
            // 展示 no-clipboard
            (_b = document
                .querySelector(".feishu-wx-container .no-clipboard")) === null || _b === void 0 ? void 0 : _b.classList.add("show");
        }
        else {
            (_c = document
                .querySelector(".feishu-wx-container .no-clipboard")) === null || _c === void 0 ? void 0 : _c.classList.remove("show");
            // 获取当前页面的图片和白板
            const images = yield getImages();
            // await createRecordDataHTML(doc, images);
            // return;
            // 样式处理
            const wrapper = createHtml(doc, images);
            // await copyToClipboard(wrapperCloned);
            // 移除 transform 点击事件
            (_d = document
                .querySelector(".feishu-wx-container .transform")) === null || _d === void 0 ? void 0 : _d.removeEventListener("click", handleTransformClick);
            // 移除 copy 点击事件
            const documentResultPage = document.querySelector(".feishu-wx-container .show-result");
            // 修改 sidebar 结构
            const result = documentResultPage ||
                PAGE_MAP["result"].cloneNode(true);
            result.querySelector(".render-area").innerHTML = "";
            result
                .querySelector(".render-area")
                .appendChild(wrapper.cloneNode(true));
            if (!documentResultPage) {
                document.querySelector(".feishu-wx-container .content").innerHTML = "";
                document
                    .querySelector(".feishu-wx-container .content")
                    .appendChild(result);
            }
            document
                .querySelector(".feishu-wx-container .copy-btn")
                .addEventListener("click", () => __awaiter(this, void 0, void 0, function* () {
                yield copyToClipboard(wrapper.cloneNode(true));
            }));
            document
                .querySelector(".feishu-wx-container .transform-btn")
                .addEventListener("click", handleTransformClick);
        }
    });
    const feishu_wx_init = () => __awaiter(this, void 0, void 0, function* () {
        // 判断当前
        // 读取 sidebar.html 文件内容
        try {
            const htmlPath = yield chrome.runtime.getURL("sidebar.html");
            const html = yield fetch(htmlPath).then((res) => {
                return res.text();
            });
            const dom = new DOMParser().parseFromString(html, "text/html").body;
            const logo = yield chrome.runtime.getURL("icon.png");
            const style = yield chrome.runtime.getURL("sidebar.css");
            // 注入样式文件
            const link = document.createElement("link");
            link.rel = "stylesheet";
            link.href = style;
            link.setAttribute("type", "text/css");
            link.setAttribute("feishu-wx-style", "feishu-wx-style");
            document.head.appendChild(link);
            // 修改 dom 中 logo 图片地址
            dom.querySelector(".logo").setAttribute("src", logo);
            const initContent = dom.querySelector("#feishu-wx-sidebar-init").content;
            const resultContent = dom.querySelector("#feishu-wx-sidebar-result").content;
            PAGE_MAP["init"] = initContent;
            PAGE_MAP["result"] = resultContent;
            dom
                .querySelector(".content")
                .appendChild(PAGE_MAP["init"].cloneNode(true));
            // 事件监听
            dom
                .querySelector(".transform")
                .addEventListener("click", handleTransformClick);
            // 注入 sidebar.html 文件内容
            document.body.appendChild(dom.firstChild);
        }
        catch (error) {
            console.error("error", error);
        }
    });
    const feishu_wx_destroy = () => {
        // 移除 sidebar.html 文件内容
        const sidebar = document.querySelector(".feishu-wx-container");
        sidebar && sidebar.remove();
        // 移除样式文件
        const style = document.querySelector("link[feishu-wx-style]");
        style && style.remove();
    };
    if (document.querySelector(".feishu-wx-container")) {
        feishu_wx_destroy();
    }
    else {
        feishu_wx_init();
    }
})();
