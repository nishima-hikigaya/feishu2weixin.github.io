/**
 * 弹窗初始化
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * 检查是否当前域名是否为飞书文档 (*.feishu.cn/docx)
 */
function checkIsFeishuDoc() {
    return __awaiter(this, void 0, void 0, function* () {
        const url = (yield getCurrentTab()).url;
        if (!url) {
            return false;
        }
        const location = new URL(url);
        return location.host.endsWith('.feishu.cn') && location.pathname.startsWith('/docx');
    });
}
function dealContent(content, recordData) {
    const wrapper = content.querySelector('div[data-docx-has-block-data]');
    if (!wrapper) {
        return [];
    }
    // 遍历处理 wrapper 子节点
    const children = wrapper.children;
    const recordMap = recordData.recordMap;
    const result = [];
    for (let i = 0; i < children.length; i++) {
        // 获取节点 classList
        const classList = Array.from(children[i].classList);
        const hLevel = children[i].className.match(/heading-(\d)/);
        if (hLevel) {
            result.push({
                type: `head${hLevel[1]}`,
                content: children[i].textContent || ''
            });
        }
        else if (classList.includes('docx-text-block')) {
            result.push({
                type: "text" /* BlockType.Paragraph */,
                content: children[i].querySelector('.ace-line>span').textContent || ''
            });
        }
        else if (classList.includes('docx-table-block')) {
            // 表格先不处理
        }
        else if (classList.includes('docx-whiteboard-block')) {
            // 白板处理
            const canvas = children[i].querySelector('canvas');
            const dataUrl = canvas === null || canvas === void 0 ? void 0 : canvas.toDataURL('image/png');
            result.push({
                type: "whiteboard" /* BlockType.Whiteboard */,
                content: dataUrl
            });
        }
        else if (classList.includes('docx-image-block')) {
            // 图片处理
            const img = children[i].querySelector('img');
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            // 确保 canvas 的尺寸与图片相同
            canvas.width = img.naturalWidth;
            canvas.height = img.naturalHeight;
            // 将图片绘制到 canvas 上
            ctx.drawImage(img, 0, 0);
            // 转换为 data URL
            const dataUrl = canvas.toDataURL('image/png');
            result.push({
                type: "image" /* BlockType.Image */,
                content: dataUrl
            });
        }
    }
    return result;
}
/**
 * 获取当前标签页 URL
 */
function getCurrentTab() {
    return __awaiter(this, void 0, void 0, function* () {
        const currentTab = yield chrome.tabs.query({ active: true, currentWindow: true });
        return currentTab[0];
    });
}
/**
 * 异常处理
 */
function errorHandler(content) {
    return (error) => {
        console.error(error);
        content.innerHTML = `<p style="color: red">${error}</p>`;
    };
}
/**
 * 将内容转换为 HTML
 */
function contentToHtml(content) {
    const headingStyle = "margin-top: 2rem; margin-bottom: 0.5rem; font-weight: 700; color: rgb(248, 95, 72); line-height: 1.35; font-size: 28px; letter-spacing: normal; text-align: start; text-wrap: wrap; font-family: Menlo, Monaco, &quot;Source Code Pro&quot;, Consolas, Inconsolata, &quot;Ubuntu Mono&quot;, &quot;DejaVu Sans Mono&quot;, &quot;Courier New&quot;, &quot;Droid Sans Mono&quot;, &quot;Hiragino Sans GB&quot;, 微软雅黑, monospace !important;";
    const paragraphStyle = "margin-top: 15px; margin-bottom: 15px; font-size: 15px; white-space: pre-line; line-height: 30px; color: rgb(74, 74, 74); letter-spacing: normal; text-align: start;";
    const template = document.createElement('div');
    for (let i = 0; i < content.length; i++) {
        const node = content[i];
        let element;
        switch (node.type) {
            case "text" /* BlockType.Paragraph */:
                if (!node.content)
                    break;
                element = document.createElement('p');
                element.setAttribute('style', paragraphStyle);
                element.textContent = node.content;
                break;
            case "heading1" /* BlockType.Head1 */:
                element = document.createElement('h1');
                element.setAttribute('style', `${headingStyle} font-size: 28px;`);
                element.textContent = node.content;
                break;
            case "heading2" /* BlockType.Head2 */:
                element = document.createElement('h2');
                element.setAttribute('style', `${headingStyle} font-size: 24px;`);
                element.textContent = node.content;
                break;
            case "heading3" /* BlockType.Head3 */:
                element = document.createElement('h3');
                element.setAttribute('style', `${headingStyle} font-size: 20px;`);
                element.textContent = node.content;
                break;
            case "heading4" /* BlockType.Head4 */:
                element = document.createElement('h4');
                element.setAttribute('style', `${headingStyle} font-size: 18px;`);
                element.textContent = node.content;
                break;
            case "heading5" /* BlockType.Head5 */:
                element = document.createElement('h5');
                element.setAttribute('style', `${headingStyle} font-size: 12px;`);
                element.textContent = node.content;
                break;
            case "whiteboard" /* BlockType.Whiteboard */:
                element = document.createElement('img');
                element.setAttribute('src', node.content);
                break;
            case "image" /* BlockType.Image */:
                element = document.createElement('img');
                element.setAttribute('src', node.content);
                break;
            default:
                break;
        }
        template.append(element);
    }
    console.log('template', template);
    return template;
}
const STYLE_MAP = {
    heading: (level) => {
        const common = `margin-top: 2rem; margin-bottom: 0.5rem; font-weight: 700; color: rgb(248, 95, 72); line-height: 1.35; font-size: ${28}px; letter-spacing: normal; text-align: start; text-wrap: wrap; font-family: Menlo, Monaco, &quot;Source Code Pro&quot;, Consolas, Inconsolata, &quot;Ubuntu Mono&quot;, &quot;DejaVu Sans Mono&quot;, &quot;Courier New&quot;, &quot;Droid Sans Mono&quot;, &quot;Hiragino Sans GB&quot;, 微软雅黑, monospace !important;`;
        let fontSize = 28;
        if (level < 4) {
            fontSize -= (level - 1) * 4;
        }
        else if (level === 4) {
            fontSize = 18;
        }
        else if (level >= 5) {
            fontSize = undefined;
        }
        return `${common} font-size: ${fontSize}px;`;
    },
    text: () => `margin-bottom: 16px; font-size: 15px; white-space: pre-line; line-height: 30px; color: rgb(74, 74, 74); letter-spacing: normal; text-align: start;`,
    list: (depth, tagType) => {
        const common = `padding-left: 30px; list-style-position: initial; list-style-image: initial; color: rgb(80, 97, 109); font-size: 15px; letter-spacing: normal; text-align: start; text-wrap: wrap; margin-top: 6px !important; list-style-type: square !important;`;
        const ULlistStyleTypeList = ['disc', 'circle', 'square'];
        const OLlistStyleTypeList = ['decimal', 'lower-alpha', 'lower-roman'];
        const listStyleTypeList = tagType === 'UL' ? ULlistStyleTypeList : OLlistStyleTypeList;
        return `${common} list-style-type: ${listStyleTypeList[depth % 3]} !important;`;
    },
    li: () => `margin-top: 6px !important;`
};
/**
 * 对 HTML 做样式处理
 */
const styleHtml = (html, imgMap) => {
    var _a, _b, _c;
    // 标题处理
    const wrapper = html.querySelector('div[data-docx-has-block-data]');
    if (!wrapper)
        return null;
    const children = Array.from(wrapper.children);
    for (let i = 0; i < children.length; i++) {
        const element = children[i];
        const classname = element.className;
        const classList = Array.from(element.classList);
        // 标题处理
        if (classname.indexOf('heading') > -1) {
            const levelMatch = classname.match(/heading-(\d)/);
            element.setAttribute('style', STYLE_MAP.heading(+levelMatch[1]));
        }
        else if (element.tagName === 'DIV' && classList.includes('ace-line')) {
            // 文本处理
            // 修改成 P 标签
            const p = document.createElement('p');
            p.innerHTML = element.innerHTML;
            p.setAttribute('style', STYLE_MAP.text());
            // p 替代原来的 div
            (_a = element.parentNode) === null || _a === void 0 ? void 0 : _a.replaceChild(p, element);
        }
        else if (element.tagName === 'UL' || element.tagName === 'OL') {
            // 列表处理
            const stack = [{
                    level: 0,
                    element
                }];
            while (stack.length) {
                const current = stack.pop();
                const { level, element } = current;
                if (element.tagName === 'UL' || element.tagName === 'OL') {
                    element.setAttribute('style', STYLE_MAP.list(level, element.tagName));
                    const lis = element.querySelectorAll(':scope >li');
                    if (lis.length) {
                        stack.push(...Array.from(lis).map(li => ({ level: level + 1, element: li })));
                    }
                }
                else if (element.tagName === 'LI') {
                    element.setAttribute('style', STYLE_MAP.li());
                    // 获取下一级 ul
                    const ulList = element.querySelectorAll(':scope > ul');
                    if (ulList.length) {
                        stack.push(...Array.from(ulList).map(ul => ({ level: level + 1, element: ul })));
                    }
                }
            }
        }
        else if (element.getAttribute('data-type') === 'image') {
            // // 获取 recordId
            // const className = element.className;
            // // recordId 存储在 classname 中格式为  old-record-id-xxxx xxxx 为字符串
            // const recordId = className.match(/old-record-id-(\S+)/)?.[1];
            // const img = element.querySelector('img');
            // const dataUrl = imgMap[recordId];
            // img.src = dataUrl ?? img.src;
        }
        else if (element.getAttribute('data-type') === 'whiteboard') {
            // 画板处理
            const className = element.className;
            // recordId 存储在 classname 中格式为  old-record-id-xxxx xxxx 为字符串
            const recordId = (_b = className.match(/old-record-id-(\S+)/)) === null || _b === void 0 ? void 0 : _b[1];
            const dataUrl = imgMap[recordId];
            if (dataUrl) {
                const img = document.createElement('img');
                img.src = dataUrl;
                element.removeChild(element.querySelector('span'));
                element.appendChild(img);
            }
            else {
                // 画板无法复制，所以将下面文字放大，颜色设置醒目颜色以做提醒
                (_c = element.querySelector('span')) === null || _c === void 0 ? void 0 : _c.setAttribute('style', 'font-size: 20px; color: red;');
            }
        }
        else if (element.querySelector(":scope > table")) {
            // 表格处理
            const table = element.querySelector(":scope > table");
            const colgroup = table.querySelector(":scope > colgroup");
            const tbody = table.querySelector(":scope > tbody");
            const firstTr = tbody === null || tbody === void 0 ? void 0 : tbody.querySelector(":scope > tr");
            // 获取每一列的宽度
            const colWidths = Array.from(colgroup === null || colgroup === void 0 ? void 0 : colgroup.querySelectorAll(":scope > col")).map(col => col.getAttribute('width'));
            const totalWidth = colWidths.reduce((prev, cur) => prev + Number(cur), 0);
            if (firstTr) {
                const pageWidth = 578;
                const tds = Array.from(firstTr.querySelectorAll(":scope > td"));
                tds.forEach((td, index) => {
                    // 取百分比向下取整
                    td.setAttribute('width', `${Math.floor(Number(colWidths[index]) / totalWidth * pageWidth)}`);
                });
            }
            // 移除 table width 属性
            table.style.removeProperty('width');
            // 删除 colgroup
            colgroup === null || colgroup === void 0 ? void 0 : colgroup.remove();
        }
        else if (element.tagName === 'PRE') {
        }
    }
    return wrapper;
};
/**
 * 初始化弹窗
 */
function initPopup() {
    return __awaiter(this, void 0, void 0, function* () {
        const isFeishuDoc = yield checkIsFeishuDoc();
        let templateId = isFeishuDoc ? 'in-feishu' : 'not-in-feishu';
        const content = document.getElementById(templateId).content;
        document.querySelector('.root').innerHTML = '';
        document.querySelector('.root').appendChild(content.cloneNode(true));
        return;
        const getHtmlBtn = document.querySelector('.in-feishu button');
        const htmlContent = document.querySelector('.in-feishu .content');
        const handleError = errorHandler(htmlContent);
        function readClipboardAsHtml() {
            return __awaiter(this, void 0, void 0, function* () {
                try {
                    // 检查剪贴板权限
                    if (!navigator.clipboard) {
                        console.error("Clipboard access is not available.");
                        return;
                    }
                    // 尝试读取剪贴板中的text/html内容
                    const text = yield navigator.clipboard.read();
                    for (const item of text) {
                        const blob = yield item.getType('text/html');
                        if (blob) {
                            const html = yield blob.text();
                            const parser = new DOMParser();
                            const doc = parser.parseFromString(html, 'text/html');
                            return doc;
                        }
                    }
                    console.log('Clipboard content:', text);
                }
                catch (err) {
                    console.error('Failed to read clipboard content:', err);
                }
            });
        }
        getHtmlBtn === null || getHtmlBtn === void 0 ? void 0 : getHtmlBtn.addEventListener('click', function () {
            return __awaiter(this, void 0, void 0, function* () {
                const doc = yield readClipboardAsHtml();
                // 判断是否是飞书文档
                if (!doc || !doc.querySelector('.lark-record-clipboard')) {
                    handleError("当前剪贴板不是飞书文档，请重新复制");
                    return;
                }
                const tab = yield getCurrentTab();
                if (!tab) {
                    handleError("获取当前标签页失败");
                    return;
                }
                const imgMapResult = yield chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: () => {
                        const result = {};
                        let count = 0;
                        while (count < 10) {
                            count += 1;
                            // 获取当前页面的 whiteboard 和 img 元素，并转换为 base64
                            const whiteboards = Array.from(document.querySelectorAll('.docx-whiteboard-block'));
                            for (let i = 0; i < whiteboards.length; i++) {
                                const canvas = whiteboards[i].querySelector('canvas');
                                const dataUrl = canvas === null || canvas === void 0 ? void 0 : canvas.toDataURL('image/png');
                                const recordId = whiteboards[i].getAttribute('data-record-id');
                                result[recordId] = dataUrl;
                            }
                            // const imgs = Array.from(document.querySelectorAll('.docx-image-block'));
                            // for (let i = 0; i < imgs.length; i++) {
                            //   const img = imgs[i].querySelector('img');
                            //   const canvas = document.createElement('canvas');
                            //   const ctx = canvas.getContext('2d');
                            //   // 确保 canvas 的尺寸与图片相同
                            //   canvas.width = img.naturalWidth;
                            //   canvas.height = img.naturalHeight;
                            //   // 将图片绘制到 canvas 上
                            //   ctx.drawImage(img, 0, 0);
                            //   // 转换为 data URL
                            //   const dataUrl = canvas.toDataURL('image/png');
                            //   const recordId = imgs[i].getAttribute('data-record-id');
                            //   result[recordId] = dataUrl;
                            // }
                            // 滚动容器
                            const scrollContainer = document.querySelector('.bear-web-x-container');
                            // 判断当前容器是不是已经滚到底
                            const isBottom = Math.abs((scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.scrollHeight) - (scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.scrollTop) - (scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.clientHeight)) < 10;
                            console.log("isBottom", isBottom, scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.scrollHeight, scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.scrollTop, scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.clientHeight);
                            if (!isBottom) {
                                // 滚动一屏
                                scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.scrollBy(0, scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.clientHeight);
                            }
                            else {
                                break;
                            }
                        }
                        return result;
                    },
                });
                console.log('doc', doc);
                // 直接修改 DOM
                const wrapperElement = styleHtml(doc, imgMapResult[0].result);
                try {
                    const data = new Blob([wrapperElement.outerHTML], { type: 'text/html' });
                    const clipboardItemData = new ClipboardItem({ 'text/html': data });
                    yield navigator.clipboard.write([clipboardItemData]);
                    console.log("已复制到剪贴板");
                    htmlContent.textContent = "已复制到剪贴板";
                }
                catch (error) {
                    handleError("复制到剪贴板失败");
                }
            });
        });
    });
}
initPopup();
